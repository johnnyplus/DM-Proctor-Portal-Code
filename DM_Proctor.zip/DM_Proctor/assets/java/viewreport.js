$('.remove').on('click',function(){
  // var handleOK = function () {
  //                 warnDialog.hide();
  //                 RightNow.Url.navigate('/cc/ajaxSubmitRoster/disableContact/'+$(this).data('id'));
  //             };
  //             var handleCancel = function () {
  //                 warnDialog.hide(); 
                  
  //             };
              
  //             var buttons = [{
  //                 text: "Yes",
  //                 handler: {
  //                     fn: handleOK, 
  //                     scope: this
  //                 },
  //                 isDefault: true
  //             },
  //             {
  //                 text: "No",
  //                 handler: {
  //                     fn: handleCancel,
  //                     scope: this
  //                 },
  //                 isDefault: false
  //             }];
  //             console.log(RightNow.UI.Dialog);
  //             var dialogBody = document.createElement("div");
  //             dialogBody.innerHTML = "Are you sure you want to remove this student record from the report?";
  //             var warnDialog = RightNow.UI.Dialog.actionDialog("Warning", dialogBody, {
  //                 "buttons": buttons,
  //                 "width": "250px"
  //             });
  //             console.log(warnDialog);
              
  //             warnDialog.show();
  var remove = confirm("warning:Are you sure you want to remove this student record from the report?");
if (remove == true) {
  window.open('/cc/ajaxSubmitRoster/disableContact/'+$(this).data('id'),'_self');
    
} 
});
$('.openMenu').on('click',function(){
  $('#desired_value').text('');
  $('#priority_submission').text('');
  $('.no-value').show();
  $('.fl-choice').hide();
  $('.sp-choice').hide();
   $('.sem-value').hide();
  $('.modal-data').hide();
  $('.edit-link').hide();
  $('.save-link').hide();
  $('.loader').show();
  $('.sem-year').html('<option value="">Select Semester</option>');
  $('.sem-year').data('contactId',$(this).data('id'));
  $.get("/cc/ajaxSubmitRoster/getSemester/"+$(this).data('id'),function(data){
      var data=jQuery.parseJSON(data)
      for(var i in data)
      {
        if(data[i])
        {
          $('.sem-year').append(" <option value='"+data[i].Year+""+data[i].sid +"'>"+data[i].semester+" "+data[i].Year+"</option>");
        }
      }
  });
  var email = $(this).parent('td').siblings(".email").text();
  $.get( "https://"+host+"/services/rest/connect/v1.3/contacts/"+$(this).data('id'), function( data ) {
    var cdata=data.customFields.c;
    var fall=(cdata.ochs_priority_fall)?cdata.ochs_priority_fall.split('-',1):'';
    var spring=(cdata.ochs_priority_spring)?cdata.ochs_priority_spring.split('-',1):'';
    $('#techId').text(data.customFields.c.digit4?data.customFields.c.digit4:'');
    $('#startId').text(data.customFields.c.starid?data.customFields.c.starid:'');
    $('#firstName').text(data.name.first);
    $('#lastName').text(data.name.last);
    
    $('#email').text(email);
    $('#eng_assessment').text((cdata.accuplacer_test_taken_english)?cdata.accuplacer_test_taken_english.lookupName:'');
    $('#math_assessment').text((cdata.accuplacer_test_taken_math)?cdata.accuplacer_test_taken_math:'');
    $('#sales_note').text((cdata.sales_notes)?cdata.sales_notes:'');
    $('#hs_transcript').text((cdata.hs_transcript_sales)?cdata.hs_transcript_sales.lookupName:'');
    $('#grad_year').text((cdata.grad_years)?cdata.grad_years.lookupName:'');
    $('.modal-data').slideDown();
    $('.loader').hide();
  });
})
$('.sem-year').on('change',function(){  
 
  $('.modal-data').hide();
  $('.loader').show();
  $('.edit-link').hide();
  $('.save-link').hide();
  if($(this).val())
  {
    $('#semYear').text($('.sem-year :selected').text());
    var str=$('.sem-year :selected').text();
    $('.no-value').show();
    $('.fl-choice').hide();
    $('.sp-choice').hide();
    $('.sem-value').hide();
    loadCourse(this);

    $.get("/cc/ajaxSubmitRoster/getSemesterDetails/"+$(this).data('contactId')+"/"+$(this).val(),function(data){
      var data=jQuery.parseJSON(data);
      setTimeout(function(){ 
              $('#semID').val(data.ID);
          $('.course-opt1').val(data.Choice1);
          $('.course-opt2').val(data.Choice2);
          $('.course-opt3').val(data.Choice3);
          $('.course-opt4').val(data.Choice4);
           $('#Choice1 .sem-value').text($('.course-opt1 :selected').text());
          $('#Choice2 .sem-value').text($('.course-opt2 :selected').text());
          $('#Choice3 .sem-value').text($('.course-opt3 :selected').text());
          $('#Choice4 .sem-value').text($('.course-opt4 :selected').text());
          $('#Status1').text((data.Choice1_Status)?data.Choice1_Status:'No Value');
          $('#Status2').text((data.Choice2_Status)?data.Choice2_Status:'No Value');
          $('#Status3').text((data.Choice3_Status)?data.Choice3_Status:'No Value');
          $('#Status4').text((data.Choice4_Status)?data.Choice4_Status:'No Value');
          $('#desired_value').text(' '+data.Desired);
          $('#priority_submission').text(data.EnrollmentPriority.substring(0, data.EnrollmentPriority.length - 1));
          // $('.sp-choice').hide();
          $('.no-value').hide();
          $('.sem-value').show();
          
      
        $('.modal-data').slideDown();
        $('.loader').hide();
       }, 2000);
      
    });
    $('.edit-link').show();
    
    
  }
  else
  {
    $('#semYear').text('');
      $('.no-value').show();
      $('.fl-choice').hide();
      $('.sp-choice').hide();
      $('.sem-value').hide();
      $('.modal-data').slideDown();
    $('.loader').hide();
  }

  
});
$('.edit-link').on('click',function(){
  // alert("Under Development");return;
  $('.save-link').show();
  $(this).hide();
      $('.sp-choice').show().removeAttr('disabled');
      $('.sem-value').hide();
});
$('.save-link').on('click',function(){
  $('.modal-data').hide();
  $('.loader').show();
  var str=$('.sem-year :selected').text();
  $('.edit-link').show();
  $(this).hide();

  var semdata={'spring_opt1':$('.sp-choice.course-opt1').val(),'spring_opt2':$('.sp-choice.course-opt2').val(),'spring_opt3':$('.sp-choice.course-opt3').val(),'spring_opt4':$('.sp-choice.course-opt4').val()};

      var postData=$.post("/cc/ajaxSubmitRoster/updateSpringSemesterDetails/"+$('#semID').val(),semdata);
      postData.done(function(){
        $('.modal-data').show();
        $('.loader').hide();
        $('.sem-year').trigger('change');
      })
  
    
});
function loadCourse(obj)
{
   if($(obj).val() != 0) {
      var ele= $(obj);
       ele.parent().parent().parent().find('.course-opt1').prop("disabled", true);
      ele.parent().parent().parent().find('.course-opt2').prop("disabled", true);
      ele.parent().parent().parent().find('.course-opt3').prop("disabled", true);
      ele.parent().parent().parent().find('.course-opt4').prop("disabled", true);
      var year = ele.val().substring(0, 4);
        var semester = ele.val().substring(4);
          $.ajax({
          type:"POST",
          url:"/cc/ajaxSubmitRoster/getCourse",
          data: {'semester': semester, 'year': year},
          //dataType: 'json',
          success: function(data) {
           
             ele.parent().parent().parent().find('.course-opt1').html('').append($('<option>').text("Select").attr('value',''));
              ele.parent().parent().parent().find('.course-opt2').html('').append($('<option>').text("Select").attr('value',''));
              ele.parent().parent().parent().find('.course-opt3').html('').append($('<option>').text("Select").attr('value',''));
              ele.parent().parent().parent().find('.course-opt4').html('').append($('<option>').text("Select").attr('value',''));
            var json = jQuery.parseJSON(data);
            $.each(json, function(index, obj) {

              ele.parent().parent().parent().find('.course-opt1').append($('<option>').text(obj.Title).attr('value',obj.CourseOfferID));
              ele.parent().parent().parent().find('.course-opt2').append($('<option>').text(obj.Title).attr('value',obj.CourseOfferID));
              ele.parent().parent().parent().find('.course-opt3').append($('<option>').text(obj.Title).attr('value',obj.CourseOfferID));
              ele.parent().parent().parent().find('.course-opt4').append($('<option>').text(obj.Title).attr('value',obj.CourseOfferID));
            });
          ele.parent().parent().parent().find('.course-opt1').prop("disabled", false);
          ele.parent().parent().parent().find('.course-opt2').prop("disabled", false);
          ele.parent().parent().parent().find('.course-opt3').prop("disabled", false);
          ele.parent().parent().parent().find('.course-opt4').prop("disabled", false);
          }
        });
    }
}