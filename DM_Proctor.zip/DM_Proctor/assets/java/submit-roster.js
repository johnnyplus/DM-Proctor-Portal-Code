
  $('#submit_roster').on('submit',function(e){
        $('#preloader').show();
        var orgID=parseInt($('#orgId').val());
        var home_campus = document.getElementsByName('Contact.CustomFields.c.home_campus')[0];
var home_campus_value = home_campus.options[home_campus.selectedIndex].value;
var grad_years = document.getElementsByName("Contact.CustomFields.c.grad_years")[0];
var grad_years_value = grad_years.options[grad_years.selectedIndex].value;
        var data={
                      'name':{
                          'first':$('#firstname').val(),
                          'last':$('#lastname').val()
                      },
                      'contactType':{
                          'id':1
                      },
                      'organization':{
                          'id':orgID
                      },
                      'emails':{
                          'address':$('#email').val(),
                          'addressType':{
                              'lookupName':'canonical',
                              'id':0
                          }
                      },
                      'customFields':{
                          'c':{
                            'home_campus':{
                              'id':parseInt(home_campus_value)
                            },
                            "ag_food_naturalresource": $('#ag_food_naturalresource').is(':checked'),
                            "art_comm_infosyst": $('#art_comm_infosyst').is(':checked'),
                            "business_manage_admin": $('#business_manage_admin').is(':checked'),
                            "engine_manufature_tech": $('#engine_manufature_tech').is(':checked'),
                            "health_science_tech": $('#health_science_tech').is(':checked'),
                            "human_services": $('#human_services').is(':checked'),
                            "grad_years":{
                              'id':parseInt(grad_years_value)
                            }
                          }
                      }
                      
                  };
      var url = 'https://'+host+'/services/rest/connect/v1.3/contacts';
      var header="";
      if($("#contactId").val())
       {
            url= "https://"+host+"/services/rest/connect/v1.3/contacts/"+$("#contactId").val();
            header = {
              "X-HTTP-Method-Override":"PATCH"
            };
       }
       $.ajax({
          url:url,
          data:JSON.stringify(data),
          type:"POST",
          headers:header,
          dataType: 'json',
          complete: function(data){
            // var fall_semYear=[];
            var spring_semYear=[];
            // var fall_coption1=[];
            // var fall_coption2=[];
            // var fall_coption3=[];
            // var fall_coption4=[];
            var spring_coption1=[];
            var spring_coption2=[];
            var spring_coption3=[];
            var spring_coption4=[];
            var spring_desired=[];
            var choice1=[];
            var choice2=[];
            var choice3=[];
            var choice4=[];
            // var fall_desired=[];
            // $(".fall-sem-year").each(function(){
            //   fall_semYear.push($(this).val());
            // });
            // $(".fall-coption1").each(function(){
            //   fall_coption1.push($(this).val());
            // });
            //  $(".fall-coption2").each(function(){
            //   fall_coption2.push($(this).val());
            // });
            //   $(".fall-coption3").each(function(){
            //   fall_coption3.push($(this).val());
            // });
            //    $(".fall-coption4").each(function(){
            //   fall_coption4.push($(this).val());
            //});
               $(".spring-sem-year").each(function(){
              spring_semYear.push($(this).val());
            });
            $(".spring-coption1").each(function(){
              spring_coption1.push($(this).val());
              choice1.push($(this).children('option:selected').text());
            });
             $(".spring-coption2").each(function(){
              spring_coption2.push($(this).val());
              choice2.push($(this).children('option:selected').text());
            });
              $(".spring-coption3").each(function(){ 
              spring_coption3.push($(this).val());
              choice3.push($(this).children('option:selected').text());
            });
               $(".spring-coption4").each(function(){
              spring_coption4.push($(this).val());
              choice4.push($(this).children('option:selected').text());
            });
            //     $(".spring-coption4").each(function(){
            //   spring_coption4.push($(this).val());
            // });
            //      $(".spring-coption4").each(function(){
            //   spring_coption4.push($(this).val());
            // });
                  $(".desired").each(function(){
              spring_desired.push($(this).val());
            });
            //        $(".fall-desired").each(function(){
            //   fall_desired.push($(this).val());
            // });
           var userId="";
            if($("#contactId").val())
            { 
               userId=$("#contactId").val();
            }
            else
            {
                userId=data.responseJSON.id;
            }
            var semdata={
                          'spring_semYear':spring_semYear,'spring_opt1':spring_coption1,'spring_opt2':spring_coption2,'spring_opt3':spring_coption3,'spring_opt4':spring_coption4,
                          //'fall_semYear':fall_semYear,'fall_opt1':fall_coption1,'fall_opt2':fall_coption2,'fall_opt3':fall_coption3,'fall_opt4':fall_coption4,
                          'userId':userId,
                          'choice1':choice1,'choice2':choice2,'choice3':choice3,'choice4':choice4,
                          'desired':spring_desired
                          //'fall_desired':fall_desired
                        };
            if($("#contactId").val())
            {         
              var posting =  $.post('/cc/ajaxSubmitRoster/updateSemester',semdata);
            }
            else
            {
              var posting =  $.post('/cc/ajaxSubmitRoster/saveSemester',semdata);
            }
            posting.done(function( data ) {
              $('#preloader').hide();
              $('.yui3-widget-mask').show();$('#popup').show();
            }); 
          }
       });
     return false;
  });
  $('.add-spring-sem').on('click',function()
  {
    var allowSem=($('.spring-sem-year:first option').length-1);
    if($('.spring-sem-year').length>=allowSem)
    {
        alert('You can not add more than '+allowSem+'  Semester.');
        return ;
    }
    $($('.spring-sem-box:first').clone().attr('style','margin-top:15px')).insertAfter('.spring-sem-box:last').find('.remove-link').show();
    $('.spring-sem-box:last').find('.spring-coption1').prop("disabled", true);
    $('.spring-sem-box:last').find('.spring-coption2').prop("disabled", true);
    $('.spring-sem-box:last').find('.spring-coption3').prop("disabled", true);
    $('.spring-sem-box:last').find('.spring-coption4').prop("disabled", true);
    // $('.spring-sem-box:last').find('.spring-coption1').removeAttr("required");
    // $('.spring-sem-box:last').find('.spring-coption2').removeAttr("required");
    // $('.spring-sem-box:last').find('.spring-coption3').removeAttr("required");
    // $('.spring-sem-box:last').find('.spring-coption4').removeAttr("required");
    $('.spring-sem-box:last').find('.desired:last').val("");
  });

  $('#submit_roster').on('change','.spring-sem-year',function()
  {
    var arr=[];
      $('.spring-sem-year').each(function(){if($(this).val()){arr.push($(this).val());}});
        var itemtoRemove = $(this).val();
        arr.splice($.inArray(itemtoRemove, arr),1);
      if(jQuery.inArray($(this).val(), arr) >= 0){
          alert('You have already selected this Semester');
          $(this).val('');
      }
      if($(this).val() != 0) {
      var ele= $(this);
       ele.parent().parent().find('.spring-coption1').prop("disabled", true);
      ele.parent().parent().find('.spring-coption2').prop("disabled", true);
      ele.parent().parent().find('.spring-coption3').prop("disabled", true);
      ele.parent().parent().find('.spring-coption4').prop("disabled", true);
      var year = ele.val().substring(0, 4);
        var semester = ele.val().substring(4);
          $.ajax({
          type:"POST",
          url:"/cc/ajaxSubmitRoster/getCourse",
          data: {'semester': semester, 'year': year},
          //dataType: 'json',
          success: function(data) {
           
             ele.parent().parent().find('.spring-coption1').html('').append($('<option>').text("Select").attr('value',''));
              ele.parent().parent().find('.spring-coption2').html('');
              ele.parent().parent().find('.spring-coption3').html('');
              ele.parent().parent().find('.spring-coption4').html('');
            var json = jQuery.parseJSON(data);
            var course;
            $.each(json, function(index, obj) { 
              course = obj.Title;
              if(obj.ID==67)
              {
                  ele.parent().parent().find('.spring-coption2').prepend($('<option>').text(course).attr('value',obj.CourseOfferID));
              ele.parent().parent().find('.spring-coption3').prepend($('<option>').text(course).attr('value',obj.CourseOfferID));
              ele.parent().parent().find('.spring-coption4').prepend($('<option>').text(course).attr('value',obj.CourseOfferID));
              ele.parent().parent().find('.spring-coption2').val(obj.CourseOfferID);
          ele.parent().parent().find('.spring-coption3').val(obj.CourseOfferID);
          ele.parent().parent().find('.spring-coption4').val(obj.CourseOfferID);
              }
              else
              {
                ele.parent().parent().find('.spring-coption1').append($('<option>').text(course).attr('value',obj.CourseOfferID));
              ele.parent().parent().find('.spring-coption2').append($('<option>').text(course).attr('value',obj.CourseOfferID));
              ele.parent().parent().find('.spring-coption3').append($('<option>').text(course).attr('value',obj.CourseOfferID));
              ele.parent().parent().find('.spring-coption4').append($('<option>').text(course).attr('value',obj.CourseOfferID));
              }
              
            });
          ele.parent().parent().find('.spring-coption1').prop("disabled", false);
          ele.parent().parent().find('.spring-coption2').prop("disabled", false);
          ele.parent().parent().find('.spring-coption3').prop("disabled", false);
          ele.parent().parent().find('.spring-coption4').prop("disabled", false);
          //ele.parent().parent().find('.spring-coption1').val(67);
          

          }
        });
    }
  });
  $('#submit_roster').on('change','.fall-sem-year',function()
  {
    var arr=[];
      $('.fall-sem-year').each(function(){if($(this).val()){arr.push($(this).val());}});
        var itemtoRemove = $(this).val();
        arr.splice($.inArray(itemtoRemove, arr),1);
      if(jQuery.inArray($(this).val(), arr) >= 0){
          alert('You have already selected this Semester');
          $(this).val('');
      }
  });
//   $('#orgId').select2({
//   ajax: {
//     url: "/cc/ajaxSubmitRoster/getOrganization",
//     dataType: 'json',
//     delay: 250,
//     data: function (params) {
//       return {
//         q: params.term, // search term
//         page: params.page
//       };
//     },
//     processResults: function (data, params) {
    
//       params.page = params.page || 1;
//       if(data)
//       {
//       return {
      
//         results: data,
//         pagination: {
//           more: (params.page * 30) < data.total_count
//         }
//       }
//      }else{
//       return  {}
//      } 
//     },
//     cache: true
//   },
//   escapeMarkup: function (markup) { return markup; }, // let our custom formatter work
//   minimumInputLength: 3
// });
  $(function(){
    var requiredCheckboxes = $('.option :checkbox[required]');
    requiredCheckboxes.change(function(){
        if(requiredCheckboxes.is(':checked')) {
            requiredCheckboxes.removeAttr('required');
        } else {
            requiredCheckboxes.attr('required', 'required');
        }
    });
});
$('.chk-btn').on('click',function(){
  var data ={'email' : $('#email').val()};
   var posting =  $.post('/cc/ajaxSubmitRoster/getDetailsByEmail',data);
    posting.done(function( data ) {
      if(data)
      {
        var data=jQuery.parseJSON(data);
        $('#orgId').val(data.Organization);
        var name= data.LookupName.split(" ");
        $('#firstname').val(name[0]);
        $('#lastname').val(name[1]);
        $('#homeCampus').val(data.home_campus_sales);
        $('#contactId').val(data.ID);
        $('#rn_SelectionInput_2 select').val(data.grad_years);
        (data.ag_food_naturalresource==1)?$('#ag_food_naturalresource').prop('checked', true):'';
        (data.art_comm_infosyst==1)?$('#art_comm_infosyst').prop('checked', true):'';
        (data.business_manage_admin==1)?$('#business_manage_admin').prop('checked', true):'';
        (data.engine_manufature_tech==1)?$('#engine_manufature_tech').prop('checked', true):'';
        (data.health_science_tech==1)?$('#health_science_tech').prop('checked', true):'';
        (data.human_services==1)?$('#human_services').prop('checked', true):'';
        if(data.Sem)
        {
            for(var i in data.Sem)
            {
                    if(i!=0)
                    {
                      $('.add-spring-sem').trigger('click');
                    }
                    $($('.spring-sem-year')[i]).val(data.Sem[i].Year+""+data.Sem[i].Semester).trigger('change');
                    $($('.desired')[i]).val(data.Sem[i].Desired);
                i++;
            }
            setTimeout(function(){
             
           var data ={'email' : $('#email').val()};
            var posting =  $.post('/cc/ajaxSubmitRoster/getDetailsByEmail',data);
                posting.done(function( data ) {
                  var data=jQuery.parseJSON(data);
                  for(var i in data.Sem)
                  {
                        $($('.spring-coption1')[i]).val(data.Sem[i].Choice1);
                        $($('.spring-coption2')[i]).val(data.Sem[i].Choice2);
                        $($('.spring-coption3')[i]).val(data.Sem[i].Choice3);
                        $($('.spring-coption4')[i]).val(data.Sem[i].Choice4);
                    
                    i++;
                  }
                   $('#loading-btn').hide();
                });
            },1500); 
           
            
        }
      
        $('.sub-btn').text("Update");
      }
      else
      {
        $('#contactId').val();
        $('#emailMessage').text("No Records found.").show();
            setTimeout(function() {
            $("#emailMessage").hide()
        }, 3000);
        $(':input').not(':button, :submit,#firstname,#lastname,#homeCampus,#email, :checkbox').val('');
        $(':checkbox').prop('checked', false);
        $('.sub-btn').text("Submit");
        $('.remove-link:visible').trigger('click');
        $('#loading-btn').hide();

      }
     
      var requiredCheckboxes = $('.option :checkbox[required]');
        if(requiredCheckboxes.is(':checked')) {
          requiredCheckboxes.removeAttr('required');
        } else {
          requiredCheckboxes.attr('required', 'required');
        }
    });  
  $('#loading-btn').css('display', 'inline-block');
})
$(function() {
  document.getElementsByName("Contact.CustomFields.c.grad_years")[0].required=true;
  document.getElementsByName("Contact.CustomFields.c.home_campus")[0].required=true;

  $('#submit_roster').on('keydown', '.numbers-only', function(e){-1!==$.inArray(e.keyCode,[46,8,9,27,13,110,190])||/65|67|86|88/.test(e.keyCode)&&(!0===e.ctrlKey||!0===e.metaKey)||35<=e.keyCode&&40>=e.keyCode||(e.shiftKey||48>e.keyCode||57<e.keyCode)&&(96>e.keyCode||105<e.keyCode)&&e.preventDefault()});
})
