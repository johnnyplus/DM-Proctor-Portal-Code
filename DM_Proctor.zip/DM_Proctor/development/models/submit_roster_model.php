<?php
/**
 * Copyright 2016, Blueleap LLC, All rights reserved.
 * www.blueleap.com
 */

//For framework 3.0
namespace Custom\Models;
use RightNow\Connect\v1_2 as RNCPHP;
require_once( get_cfg_var("doc_root")."/ConnectPHP/Connect_init.php" );
class Submit_roster_model extends \RightNow\Models\Base
{

	function __construct()
    {
        parent::__construct();
		\RightNow\Libraries\AbuseDetection::check();
        //This model would be loaded by using $this->load->model('custom/Sample_model');
    }
    function roql_delete_query($id)
    {
    	$roql="SELECT ID from CoursesObj.Course_Selection where Contact='".$id."'";		
		$response=$this->roql_tabular_query($roql);
		if(count($response)>0)
		{
			foreach ($response as $value) {
				$sem = RNCPHP\CoursesObj\Course_Selection::fetch($value['ID']);
				$sem->destroy();
			}
		}
		

    }
	function roql_tabular_query($query)
    {  
	    try
    	{	
			$roql_result_set = RNCPHP\ROQL::query( $query );	
			
			while ($roql_result = $roql_result_set->next())
			{		
			    unset($datasets);
				$count=0;
				//$dataset['count'] = 0;

    			while ($row = $roql_result->next())
	    		{			
		    		foreach ($row as $key => $value)
			    	{
				
					    $datasets[$count][$key]=$value;
				    }

				    $count++;
			    }	
			}
		
		} catch ( \Exception $err )
	    {
    	    $datasets['exception'] = $err->getMessage();
	    };


		return($datasets);

  	}
	function roql_tabular_insert($query)
    {  
	    try
    	{	
			$roql_result_set = RNCPHP\ROQL::query( $query );		
			
		
		} catch ( \Exception $err )
	    {
    	    $datasets['exception'] = $err->getMessage();
	    };


		return($datasets);

  	}
  
	function saveSpringSemester($array)
	{
		$semester = new RNCPHP\CoursesObj\Course_Selection();
		$semester->Contact = (int)$array['ContactID'];
		$semester->Choice1 = (int)$array['Spring_First_Choice'];
		$semester->Choice_1st = $array['Choice_1st'];
		
			$semester->Choice2 = (int)$array['Spring_Second_Choice'];
			$semester->Choice_2nd = $array['Choice_2nd'];
		
		
			$semester->Choice3 = (int)$array['Spring_Third_Choice'];
			$semester->Choice_3rd = $array['Choice_3rd'];
		
		
			$semester->Choice4 = (int)$array['Spring_Fourth_Choice'];
			$semester->Choice_4th = $array['Choice_4th'];
		
		
		
		
		
		
		$semester->Desired = (int)$array['Desired'];
		$semester->Semester = (int)substr($array['SpringSemestersName'],4);
		$semester->Year = substr($array['SpringSemestersName'],0,4);
		$semester->EnrollmentPriority=time();
		$semester->ProctorName = $array['ProctorName'];
		$semester->ProctorID = $array['ProctorId']->value;
		$semester->save();
		
	}
	
	function updateSpringSemester($id,$array)
	{
		$isChanged=false;
		$roql = "SELECT * FROM CoursesObj.Course_Selection where id='$id'";
		$resultSet = RNCPHP\ROQL::query($roql);
		$queryResults = $resultSet->next();
		$semester=$queryResults->next();
		
		$semesterObj =  RNCPHP\CoursesObj\Course_Selection::fetch($id);
		if ($semester['Choice1']!=$array['First_Choice'])
		{
			$isChanged=true;
			$semesterObj->Choice1_Status= 63;
		}
		if($semester['Choice2']!=$array['Second_Choice'])
		{
			$isChanged=true;
			$semesterObj->Choice2_Status= 64;
		}
		if($semester['Choice3']!=$array['Third_Choice'])
		{
			$isChanged=true;
			$semesterObj->Choice3_Status= 65;
		}
		if($semester['Choice4']!=$array['Fourth_Choice'])
		{
			$isChanged=true;
			$semesterObj->Choice4_Status= 66;
		}

		$semesterObj->Choice1 = (int)$array['First_Choice'];
		$semesterObj->Choice2 = (int)$array['Second_Choice'];
		$semesterObj->Choice3 = (int)$array['Third_Choice'];
		$semesterObj->Choice4 = (int)$array['Fourth_Choice'];
		$semesterObj->save();
		if($isChanged)
		{ 
			$incident = new RNCPHP\Incident();
			$incident->Topic="Courses";
			$incident->Subject="Student Roster Modified by Proctor";
			$incident->Queue->ID=43;
			$incident->CustomFileds->c->referred="OCHS";
			$incident->PrimaryContact=(int)$semester['Contact'];
			$incident->Mailbox=112;
			$incident->save();
		}
	}
	function getCourse($semester, $year) {
			
			$data = array();
			
			try {
				$roql = "select course from CoursesObj.Course_Offer where semester =".$semester." and year=".$year." order by ID";
				
				//$roql = "select course from scong.Course_Offer where semester = 1 and year = 2017";
				$res = RNCPHP\ROQL::queryObject($roql)->next();
				
				$i = 0;
				
				while($course = $res->next()) {
					
					$roqlOffer = "select CoursesObj.Course_Offer.ID from CoursesObj.Course_Offer where semester =".$semester." and year=".$year." and course=".$course->ID;
					$arr = RNCPHP\ROQL::query($roqlOffer)->next();
					$courseOffer = $arr->next();
					$query = "select CoursesObj.course from CoursesObj.course where ID = ".$course->ID;
					$result = RNCPHP\ROQL::queryObject($query)->next();
					$code = $result->next();
					$code->CourseOfferID = $courseOffer['ID'];
					$aCourse = $code->Code.' '.$code->Title;
					//array_push($data, $aCourse);
					array_push($data, $code);
					//$i++;
				}
			}
			catch(RNCPHP\ConnectAPIError $error) {
				//return $error->getMessage();
				print_r($error);
				//return $error->getCode();
			}
			
			return $data;
			
	}
	function saveIncident($id)
	{
		$incident = new RNCPHP\Incident();
		$incident->Topic="Courses";
		$incident->Subject="New Student Roster Submitted";
		$incident->Queue->ID=43;
		$incident->CustomFileds->c->referred="OCHS";
		$incident->PrimaryContact=(int)$id;
		$incident->Mailbox=112;
		$incident->save();
	}

	function disableContact($contactId)
	{
		$contact = RNCPHP\Contact::fetch($contactId);
		$contact->disabled = true;
		$contact->save();

	}
 }