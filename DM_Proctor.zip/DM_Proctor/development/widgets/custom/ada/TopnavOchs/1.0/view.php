<?php $uri_arr = explode("/",$_SERVER['REQUEST_URI']); ?>
<nav>
	<div class="common">
    <div class="navbar-header">
      <button type="button" id="clickme" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"> 
      <span class="sr-only">Toggle navigation</span> 
      <span class="icon-bar"></span> 
      <span class="icon-bar"></span> 
      <span class="icon-bar"></span> 
      </button>
      <a href="#skip">Skip to Main Content ></a>
      </div>
<input type="hidden" id="contactType" value='<rn:field name="Contact.contactType"/>' />
        <ul id="show">
        <rn:condition logged_in="true">
                <li class="online-programs view-report" style="display:none"><a href="/app/custom/ochs/submit-roster" <?php if(in_array($uri_arr[count($uri_arr) - 1],array('proctor'))) echo 'class="active"'; ?>>Submit Roster</a>
                	<ul class="submenu">
				<li><a href="/app/custom/ochs/proctor">View Report</a></li>
				
			</ul>
                </li>
        </rn:condition>
            <li>
			<a href="/app/custom/ochs/pathway/career-pathways" <?php if(in_array($uri_arr[count($uri_arr) - 1],array('career-pathways','career-agriculture','career-arts','career-business','career-engineering','career-health','career-human'))) echo 'class="active"'; ?>>CAREER PATHWAYS</a>
			 <ul class="submenu">
				<li><a href="/app/custom/ochs/pathway/career-agriculture">Agriculture, Food & Natural Resources</a></li>
				<li><a href="/app/custom/ochs/pathway/career-arts">Arts, Communications & Information Systems</a></li>
				<li><a href="/app/custom/ochs/pathway/career-business">Business, Management, & Administration</a></li>
				<li><a href="/app/custom/ochs/pathway/career-engineering">Engineering, Manufacturing, & Technology</a></li>
				<li><a href="/app/custom/ochs/pathway/career-health">Health Science Technology</a></li>
				<li><a href="/app/custom/ochs/pathway/career-human">Human Services</a></li>
                		<li><a href="/app/custom/ochs/pathway/skills">Skills</a></li>
			</ul>
			</li>
            <li>
			<a href="/app/custom/ochs/course-registration" <?php if(in_array($uri_arr[count($uri_arr) - 1],array('course-registration', '3028'))) echo 'class="active"'; ?>>Courses</a>
			<ul class="submenu">
					<li><a href="/app/answers/ochs-detail/a_id/3028">Registration</a></li>
					<li><a href="/app/custom/ochs/course-books">Book Listing</a></li>
			</ul>
			</li>
            <li>
			<a href="/app/custom/ochs/high-school-resources" <?php if(in_array($uri_arr[count($uri_arr) - 1],array('high-school-resources'))) echo 'class="active"'; ?>>High School Resources</a>
		<!--	<ul class="submenu">
            
            <li><a href="/app/custom/ochs/students">Student Center</a></li>
				<li><a href="mailto:distancemn@custhelp.com">Memorandum of Agreement - Submit Request</a></li>
				<li><a href="#">Concurrent Enrollment Aide Application</a></li>
				<li><a href="#">Course Details</a></li>
			</ul>-->
			</li>
            
            
                        <li>
			<a href="/app/custom/ochs/students" <?php if(in_array($uri_arr[count($uri_arr) - 1],array('students'))) echo 'class="active"'; ?>>Student Center</a>
			 <!--<ul class="submenu">
            
           <li><a href="/app/custom/ochs/students">Student Center</a></li>
				<!--<li><a href="mailto:distancemn@custhelp.com">Memorandum of Agreement - Submit Request</a></li>
				<li><a href="#">Concurrent Enrollment Aide Application</a></li>
				<li><a href="#">Course Details</a></li>
			</ul>-->
			</li>
            
            
            
            
            
            
            
            
            <li>
			<a href="/app/custom/ochs/about-us" <?php if(in_array($uri_arr[count($uri_arr) - 1],array('about-us', 'info_ochs', '3207','coordinators'))) echo 'class="active"'; ?> >ABOUT US</a>
			<ul class="submenu">
				<!--<li><a href="/app/custom/students/ochs/enrollment-opportunities">Enrollment Opportunities</a></li>
				<li><a href="/app/answers/ochs-detail/a_id/1801">Student Eligibility</a></li>
				<li><a href="/app/custom/students/ochs/course-registration">Available Courses</a></li>
				<li>
				<a href="#">Student Information Hand-out</a>
				<ul class="subsubmenu">
					<li><a href="/app/answers/ochs-detail/a_id/4236" target="_blank">Black/White</a></li>
					<li><a href="/app/answers/ochs-detail/a_id/4237" target="_blank">Color</a></li>
				</ul>
				</li>
				<li><a href="/app/answers/ochs-detail/a_id/930">Important Dates</a></li>-->
			
                <li><a href="/app/custom/ochs/contact-ochs">Contact us</a></li>
				<li><a href="/app/custom/ochs/coordinators">Learning Coordinators</a></li>
                	<li><a href="/app/answers/detail/a_id/3207" target="_blank">Student Success Report</a></li>
			</ul>
			</li>
        </ul>
     </div>
</nav>
<script>
($('#contactType').val()=="Proctor")? $('.view-report').show():$('.view-report').hide();
</script>
