<!DOCTYPE html>
<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" xmlns:rn="http://schemas.rightnow.com/crm/document" lang="en" xml:lang="en" >
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!--<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">-->
<title>
<rn:page_title />
</title>
<!-- Begin Facebook meta tags -->
<meta name="google-site-verification" content="QFSNHJ_j2Ezn6v2oih3UDocFgyx0ZYN24tGqyHIY7a0" />
<link rel="shortcut icon" type="image/x-icon" href="/euf/assets/images/favicon.ico" />
<meta name="description" content="Online college in the high school is a contract program with Minnesota State system colleges" />
<meta name="keywords" content="pseo, concurrent, senior, junior, college-credit, contract" />
<meta property="og:title" content="Online College in the High School" />
<meta property="og:type" content="non_profit" />
<meta property="og:url" content="http://onlinecollegeinthehighschool.org" />
<meta property="og:image" content="" />
<meta property="og:site_name" content="Online College in the high school" />
<meta property="fb:admins" content="710931620" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- End Facebook meta tags-->
<!--<link rel="stylesheet" href="/euf/assets/themes/standard/site.css" type="text/css" >-->

<rn:theme path="/euf/assets/themes/standard" css="/rnt/rnw/yui_2.7/container/assets/skins/sam/container.css" />
<!-- <link rel="stylesheet" href="/euf/assets/css/ada_validated.css" type="text/css"  media="screen" /> -->
<link rel="stylesheet" href="/euf/assets/css/styles-new.css" type="text/css"  media="screen" />
<script src="/euf/assets/java/jquery-1.11.0.js"></script>
<!-- <link rel="stylesheet" href="/euf/assets/css/print.css" type="text/css" media="print"/> -->
<link href="/euf/assets/css/js-image-slider.css" rel="stylesheet" type="text/css" />

<link href="/euf/assets/css/print-ochs.css" rel="stylesheet" type="text/css" media="print"/>
<!-- Fonts -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Josefin+Slab:100,300,400,600,700,100italic,300italic,400italic,600italic,700italic" rel="stylesheet" type="text/css">
<link href='https://fonts.googleapis.com/css?family=Glegoo' rel='stylesheet' type='text/css'>
<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
<link href="/euf/core/static/ma.css" rel="stylesheet" type="text/css"/>


<script type="text/javascript" src="/rnt/rnw/javascript/enduser.js" language="JavaScript"></script>


<script language="javascript">
var popupWindow = null;
function positionedPopup(url,winName,w,h,t,l,scroll){
settings =
'height='+h+',width='+w+',top='+t+',left='+l+',scrollbars='+scroll+',resizable'
popupWindow = window.open(url,winName,settings)
}
</script>



<!--google code for OCHS template - from Becky 8-17-16-->

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-15870636-1', 'auto');
  ga('send', 'pageview');

</script>

<!--google code for OCHS template - from Becky 8-17-16-->

<style type="text/css">
    .yui3-widget-mask{
        background: rgba(0,0,0,0.7);
    }
    .yui3-widget
    {
        position: fixed !important;
        background: #fff;
    }
    .yui3-widget-hd{
        display: none;
    }
    .yui3-panel-hidden{
      display: none;
    }
    .common{
        width: 970px
    }
</style>
</head>
<body>
<!-- Begin Header -->
<header>

	<div class="common">
        <div class="logo">
            <a href="/app/custom/students/ochs/index" title="home"><h1><span style="display:none">Online College in the High School</span><img src="/euf/assets/images/new-imgs/logo.png" alt="Online College" /></h1></a>
        </div>
        <div class="skipcont">
            <div class="skip"><a href="#skip">Skip to Main Content ></a></div>
  <!--Edison -->
		<div id="login">
		<div id="rn_LoginStatus" class="login">
            <rn:condition logged_in="true">
                 #rn:msg:WELCOME_BACK_LBL#
                <strong>
                    <rn:field name="Contact.LookupName"/><rn:condition language_in="ja-JP">#rn:msg:NAME_SUFFIX_LBL#</rn:condition>
                </strong>
                <div>
                    <rn:field name="Contact.Organization.LookupName"/>
                </div>
                <rn:widget path="login/LogoutLink" redirect_url="/app/custom/students/ochs/index"/>
            <rn:condition_else />
                <rn:condition config_check="PTA_ENABLED == true">
                    <a href="javascript:void(0);" id="rn_LoginLink">Mentor Log In</a>&nbsp;|&nbsp;<a href="javascript:void(0);">#rn:msg:SIGN_UP_LBL#</a>
                <rn:condition_else />
                    <a href="javascript:void(0);" id="rn_LoginLink">Mentor Log In</a>&nbsp;|&nbsp;<a href="/app/utils/create_account#rn:session#">#rn:msg:SIGN_UP_LBL#</a>
                    <rn:condition hide_on_pages="utils/create_account, utils/login_form, utils/account_assistance">
                        <rn:widget path="login/LoginDialog" label_username="Email address" trigger_element="rn_LoginLink" open_login_url=""/>
                    </rn:condition>
                    <rn:condition show_on_pages="utils/create_account, utils/login_form, utils/account_assistance">
                        <rn:widget path="login/LoginDialog" open_login_url="" trigger_element="rn_LoginLink" redirect_url="/app/account/overview"/>
                    </rn:condition>
                </rn:condition>
            </rn:condition>
		</div>
	</div>
<!--Edison -->

            <div class="backmn"><!--<a href="/"><img src="/euf/assets/images/new-imgs/backbtn.jpg" alt="Back to Distance MN" /></a>-->
         
         <a href="https://distanceminnesota.org/app/chat/pro_chat_launch" onclick="positionedPopup(this.href,'myWindow','375','750','100','200','no');return false"><img src="/euf/assets/images/new-imgs/Hdr_circle-chat-tan-black.png"  alt="Chat" /></a>
         
            
    
            <a href="https://distanceminnesota.org/app/ask-ochs" onclick="positionedPopup(this.href,'myWindow','375','825','100','200','yes');return false"> 
            
            <img src="/euf/assets/images/new-imgs/Hdr_circle-question-tan-black.png" alt="Ask a question" /></a>
              <a href="/app/custom/ochs/high-school-resources"><img src="/euf/assets/images/new-imgs/Hdr_circle-resources-tan-black.png" alt="Resources" /></a>
            
            
            </div>
        </div>
    </div>
</header>
<!-- End Header -->
<!-- Begin Navigation -->  
<rn:widget path="custom/ada/TopnavOchs"/>
<!-- End Navigation -->
<!-- Begin MainContent -->
  <main id="maincontent">  

  <rn:page_content/>
  </main>
<!-- End MainContent -->
<!-- Begin Footer -->
<footer>
  <div class="common">
      	<div class="footerleft">
        	<a href="/"><img src="/euf/assets/images/new-imgs/footer-logo.jpg" alt="distanceminnesota" /></a>
            <p>© 2016 Distance Minnesota. All Rights Reserved.<br/>
Distance Minnesota is an Equal Opportunity employer and educator. </p>
			<img src="/euf/assets/images/new-imgs/oracle.jpg" alt="oracle" />
        </div>
        <div class="footerright">
        	<div class="logos">
            	<img src="/euf/assets/images/new-imgs/footerlogo1.png" alt="Alexandria Technical and Community College" />
                <img src="/euf/assets/images/new-imgs/footerlogo2.png" alt="Bemidji State University" />
              <!--  <img src="/euf/assets/images/new-imgs/footerlogo3.png" alt="footerlogo3" />-->
                <img src="/euf/assets/images/new-imgs/footerlogo4.png" alt="Northland Community and Technical College" />
                <img src="/euf/assets/images/new-imgs/footerlogo5.png" alt="Northwest Technical College" />
                
            </div><br/><br/>
                <p>Members of the Minnesota State system</p>
            <div class="links">
            <ul>
            	<li><a href="/app/answers/detail/a_id/865" target="_blank">PRIVACY POLICY</a></li>
                <li><a href="/app/custom/terms_of_use" target="_blank">TERMS OF USE</a></li>
                <li><a href="#">SITE MAP</a></li>
            </ul>  
            </div>
        </div>
    </div>
</footer>
<!-- End Footer -->

<script>
jQuery( "#clickme" ).click(function() {
jQuery( "#show" ).toggle( "down", function() {
// Animation complete.
});
});
</script>



</body>
</html>