
<rn:meta title="High School Resources - Online College in the High School - Distance Minnesota" template="DMN_index_ochsnew.php" clickstream="home"/>
<link rel="stylesheet" href="/euf/assets/bootstrap.min.css">
<link rel="stylesheet" href="/euf/assets/css/styles-new.css" type="text/css" media="screen">
<style>
nav ul ul li a {
width: 100%;
padding: 10px 9%;
}
.common{
  width: 970px
}
.m-b-10{
	margin-bottom: 10px; 
}
.sp-choice{
	max-width: 150px;
}
</style>
<script src="/euf/assets/jquery.min.js"></script>
<script src="/euf/assets/bootstrap.min.js"></script>
<main class="internal">
<?php 
// $roql = "SELECT * FROM CoursesObj.Choice2_Status";
// $resultSet = RightNow\Connect\v1_2\ROQL::query($roql);
// $queryResults = $resultSet->next();
// while($data = $queryResults->next())
// {
//     var_dump($data);
// }
// die; 
?>
<?php 
function paginationLink($total,$limit)
{
   $_GET['page']=(isset($_GET['page']))?$_GET['page']:1;
        echo '<div class="row">'; 
          echo '<div class="col-md-12">';
            $totalrecord_data['total']=$total;
            if($totalrecord_data['total']>0)  
            {
              $lastpage = ceil($totalrecord_data['total']/$limit);
              if($lastpage>1)
              {
                echo '<ul class="pagination">';
                  if(@$_GET['page']>1)
                  {
                    echo '<li><a href="'.$_SERVER['REQUEST_URI'].'?page=1">&laquo;</a></li>';
                  }

                  $maxpage_display = 5;
                  $startpage=1;
                  if($lastpage>$maxpage_display)
                  {
                    $endpage=$maxpage_display;
                  }
                  else
                  {
                    $endpage=$lastpage; 
                  }
                  if(@$_GET['page']<$maxpage_display){$startpage = 1;} 
                  else {
                    $startpage = abs($_GET['page']-2);

                    if(($_GET['page']+2)<$lastpage) {
                      $endpage = abs($_GET['page']+2);
                    }else {$endpage = $lastpage;}
                  }

                  if($startpage>4)
                  {
                    echo '<li><a href="'.$_SERVER['REQUEST_URI'].'?page='.($startpage-2).'">&larr; Prev</a></li>';
                  }

                  for($a=$startpage;$a<=$endpage;$a++)
                  {
                    if(@$_GET['page']==$a) {
                      echo '<li class="active"><a href="'.$_SERVER['REQUEST_URI'].'?page='.$a.'">'.$a.'</a></li>';
                    } else {
                      echo '<li><a href="'.$_SERVER['REQUEST_URI'].'?page='.$a.'">'.$a.'</a></li>';
                    }
                  }

                  if($endpage<($lastpage-3))
                  {
                    echo '<li><a href="'.$_SERVER['REQUEST_URI'].'?page='.($endpage-2).'">Next &rarr;</a></li>';
                  }
                  
                  if(@$_GET['page']<$lastpage)
                  {
                    echo '<li><a href="'.$_SERVER['REQUEST_URI'].'?page='.$lastpage.'">&raquo;</a></li>';
                  }
                echo '</ul>';
              } 
            }

          echo '</div>';    
        echo '</div>';
}


?>
<div class="inner-waper ochs-waper">
  <div class="common" style="text-align:center"> 
    <?php
    // require_once(get_cfg_var('doc_root')."/ConnectPHP/Connect_init.php");
    // initConnectAPI();
    $OrgID=($this->session->getProfile()->org_id->value)?$this->session->getProfile()->org_id->value:'';
    if($OrgID)
    {
    $currPage=(isset($_GET['page']))?$_GET['page']:1;
    $offset=($currPage-1)*15;
    $roql = "SELECT  count(DISTINCT Contact) as count FROM CoursesObj.Course_Selection where Contact !='' and ProctorID='".$this->session->getProfile()->c_id->value."' and Contact.disabled='false'";
    $resultSet = RightNow\Connect\v1_2\ROQL::query($roql);
    $queryResults = $resultSet->next();
    $count=$queryResults->next();
    
     $roql = "SELECT Contact FROM CoursesObj.Course_Selection where Contact !='' and ProctorID='".$this->session->getProfile()->c_id->value."' and Contact.disabled='false' group by Contact order by Contact.customFields.c.grad_years,Contact.name.last LIMIT $offset,15 ";
    // $roql = "SELECT * FROM contact where Organization=".$OrgID." and ContactType IN (1,12,13,14,15,16,17) limit $offset,15";
    $resultSet = RightNow\Connect\v1_2\ROQL::query($roql);
    $queryResults = $resultSet->next();
    ?>
    <table style="width:100%" class="table table-hover table-striped">
      <thead style="background-color:orange">
        <tr>
          
          <th style="width:50px">Tech ID</th>
          <th style="width:50px">Start ID</th>
          <th>First Name</th>
          <th>Last Name</th>
          <th>Email</th>
          <th>High school</th>
          <th>Grade Year</th>
          <th style="width:150px">ACTION</th>
        </tr>
      </thead>
      <tbody>
        <?php
    
        if($count['count']>0)
        {
        $i=1;
        while($data = $queryResults->next())
        {
 
        $roql = "SELECT LookupName,contact.organization.lookupName as organization,contact.Emails.EmailList.Address,contact.customFields.c.digit4,contact.customFields.c.starid,contact.customFields.c.grad_years.lookupName as gradYear FROM contact where ID=".$data['Contact'];
        $resultSetEmail = RightNow\Connect\v1_2\ROQL::query($roql);
        $queryResultsEmail = $resultSetEmail->next();
        $dataEmail = $queryResultsEmail->next();
        //if($dataEmail)
        {

$name = explode(' ',$dataEmail['LookupName']);
       
        ?>
        <tr>
          
          <td><?= $dataEmail['digit4'] ?></td>
          <td><?= $dataEmail['starid']?></td>
          <td><?= $name[0] ?></td>
          <td><?= $name[1] ?></td>
          <td class="email"><?= $dataEmail['Address']?></td>
          <td><?= $dataEmail['organization']?></td>
          <td><?= $dataEmail['gradYear']?></td>
          <td><a  data-toggle="modal" data-target="#studentDetails"  class="openMenu" data-id="<?= $data['Contact'] ?>" style="cursor:pointer">open</a>
<a   class="remove" data-id="<?= $data['Contact'] ?>" style="cursor:pointer">Remove</a>
          </td>

        </tr>
        <?php 
}
        } } ?>
      </tbody>
    </table>
    <?php 

    paginationLink($count['count'],15) ?>
    <?php }else{ echo "Please login to check reports."; }?>
  </div>
</div>
<div id="studentDetails" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Student Roster Information</h4>
      </div>
      <div class="modal-body">
        <div class="loader text-center">
          <img src="/euf/assets/images/loading.gif" height="40px">
        </div>
        <div class="modal-data">
          <div class="row m-b-10">
            <div class="col-md-3">
              <b>Tech Id :</b>
            </div>
            <div class="col-md-3" id="techId">
            </div>
            <div class="col-md-3">
              <b>Start Id :</b>
            </div>
            <div class="col-md-3" id="startId">
            </div>
          </div>
          <div class="row m-b-10">
            <div class="col-md-3">
              <b>First Name :</b>
            </div>
            <div class="col-md-3" id="firstName">
            </div>
            <div class="col-md-3">
              <b>Last Name :</b>
            </div>
            <div class="col-md-3" id="lastName">
            </div>
          </div>
          <div class="row m-b-10">
            <div class="col-md-3">
               <b>Grad Year:</b>
            </div>
            <div class="col-md-3" id="grad_year"></div>
            <div class="col-md-2">
               <b>Email:</b>
            </div>
            <div class="col-md-4" id="email"></div>
          </div>
          <div class="row m-b-10">
          	<div class="col-md-6">
              <b>H.S. Transcript :</b>
            </div>
            <div class="col-md-6" id="hs_transcript">
            </div>
            
            
            
          </div>
          <div class="row m-b-10">
            <div class="col-md-6">
              <b>English Assessment:</b>
            </div>
            <div class="col-md-6" id="eng_assessment">
            </div>
            
          </div>
          <div class="row m-b-10">
            <div class="col-md-6">
              <b>Math Assessment:</b>
            </div>
            <div class="col-md-6" id="math_assessment">
            </div>
            
          </div>
          <div class="row m-b-10">
            <div class="col-md-3">
             <b>Proctor Note :</b>  
            </div>
          <div class="col-md-9" id="sales_note">  
            </div>
            
          </div>
         
          <div class="row m-b-10" style="margin-top:15px">
            <div class="col-md-12">
              <table class="table table-striped">
                <tbody>
                  <tr>
                    <td colspan="3"> 
                      <select class="sem-year" name="semYear" required>
                        <option value="">Select Semester</option>
                    </select>
                  </td>
                    
                  </tr>
                  <tr>
                    <td  colspan="2"   ><b>Enrollment Priority: <span id="priority_submission"></span></b></td>
                   
                    <td><b>Courses Desired:<span id="desired_value"></span></b></td>
                  </tr>
                  <tr>
                    <td  colspan="2" id="semYear" style="font-weight: bold;"  ></td>
                    <td><b>Status </b></td>
                  </tr>
                  <tr>
                    <td>1st Choice</td>
                    <td id="Choice1"><span class="no-value">No Value</span>
                        <span class="sem-value" style="display: none"></span>
              					<select class="course-opt1 sp-choice" name="coption1[]" required style="display: none">
              						<option value="">Select</option>
              						
              					</select>
              	
                    </td>
                    <td id="Status1"><span class="no-value">No Value</span></td>
                  </tr>
                  <tr>
                    <td>2nd Choice</td>
                    <td id="Choice2"><span class="no-value">No Value</span>
                     <span class="sem-value" style="display: none"></span>
                    	<select class="course-opt2 sp-choice" name="coption1[]" required style="display: none">
              						<option value="">Select</option>
              						
            					</select>
            					
                    </td>
                    <td id="Status2"><span class="no-value">No Value</span></td>
                  </tr>
                  <tr>
                    <td>3rd Choice</td>
                    <td id="Choice3"><span class="no-value">No Value</span>
                     <span class="sem-value" style="display: none"></span>
                    	<select class="course-opt3 sp-choice" name="coption1[]" required style="display: none">
              						<option value="">Select</option>
              						
					           </select>
          					

                    </td>
                    <td id="Status3"><span class="no-value">No Value</span></td>
                  </tr>
                  <tr>
                    <td>4th Choice</td>
                    <td id="Choice4"><span class="no-value">No Value</span>
                     <span class="sem-value" style="display: none"></span>
                    	<select class="course-opt4 sp-choice" name="coption1[]" required style="display: none">
            						<option value="">Select</option>
            						
            					</select>
                			
                    </td>
                    <td id="Status4"><span class="no-value">No Value</span></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          <div class="row text-center">
          <input type="hidden" id="semID">
            <a class="btn btn-success edit-link" style="display: none">EDIT</a>
            <a class="btn btn-success save-link" style="display: none">SAVE</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
</main>
<script type="text/javascript">
  var host="<?= $_SERVER['SERVER_NAME']?>" ;
</script>
<script src="/euf/assets/java/viewreport.js?ver=20170511"></script>