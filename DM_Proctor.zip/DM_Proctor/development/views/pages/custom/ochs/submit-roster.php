<rn:meta title="High School Resources - Online College in the High School - Distance Minnesota" template="DMN_index_ochsnew.php" clickstream="home"/>
 <style type="text/css">
   #rn_SelectionInput_2_LabelContainer,.yui3-widget-positioned{
    display: none;
   }
 </style>
 <div id="preloader" style="display: none"></div>
 <div class="yui3-widget-mask" style="position: fixed;display: none; width: 100%; height: 100%; top: 0px; left: 0px; z-index: 9999;"></div>
 <div id="popup" style="display: none">
    <p>Student Data sucessfully submited</p>
    <button onclick="location.reload()">Add New</button><button onclick="window.location=window.location.href.replace('submit-roster','proctor')">View Report</button>
 </div>
<link rel="stylesheet" href="/euf/assets/css/select2.min.css" type="text/css"  media="screen" />
<script src="/euf/assets/select2.min.js"></script>
<link rel="stylesheet" href="/euf/assets/css/proctor.css" />
<main class="internal">
<div class="inner-waper ochs-waper">
  <div class="common">
    <form method="post" id="submit_roster" onsubmit="return false;">
    <div id="rn_ErrorLocation"></div>
    <input type="hidden" id="contactId">
      <h1 style="text-align: center;margin-bottom: 0;">Enrollment Roster</h1>
      <fieldset class="scheduler-border">
        <legend >Student Detail</legend>
        <table style="width: 100%">
        
        <tr>
            <td style="width: 190px;">Student Email Address</td>
            <td colspan="3" >
              <input type="email" name="email" id="email" required="" style="width: 42%;"/>
              <a class="chk-btn" style="margin-left: 15px;">Search for student record</a>
              <img src="/euf/assets/loading.gif" id="loading-btn" style="display: none;vertical-align: middle;margin-left: 10px;">
              <span id="emailMessage" style="display: none;margin-left: 10px;color: #f00"></span>
            </td>

            
          </tr>
        
        
          <tr>
            <td>High School</td>
            <td>
              <select required id="orgId" name="orgname" style="width: 80%">

                <option value="">Select</option>
                <option value="<?= $this->session->getProfile()->org_id->value;?>" selected><rn:field name="Contact.Organization.LookupName"/></option>
              <?php
              $roql = "SELECT OrganizationId FROM SemesterObj.ContactOrg where SemesterObj.ContactOrg.ContactId ='".$this->session->getProfile()->c_id->value."'";
	
		$response = $this->model('custom/Submit_roster_model')->roql_tabular_query($roql);
		if(!empty($response))
		{
		  foreach ($response as $key => $value) {
		  	$id[]=$value['OrganizationId'];
		  }
	
		 $roql = "SELECT ID as id,LookupName as text FROM Organization where  ID IN (".implode(',', $id).")";
		$response = $this->model('custom/Submit_roster_model')->roql_tabular_query($roql);
		foreach ($response as $key => $value) {?>
			<option value="<?php echo $value['id'] ?>"><?php echo $value['text'] ?></option>
		<?php }

		}
              ?>
              </select>
            </td>
            <td style="width: 150px;">Home Campus</td>
            <td>
            <rn:widget path="input/SelectionInput" label_input=""  name="contacts.c$home_campus" required="true" > 
            </td>
          </tr>
          
          
          <tr>
          <td>FirstName</td>
            <td><input type="text" name="firstname" id="firstname" required=""/></td>
            <td>LastName</td>
            <td><input type="text" name="lastname" id="lastname" required=""/></td>
          </tr>
           <tr>
        
          <td>Graduation Year</td>
            <td>



            <rn:widget path="input/SelectionInput" label_input=""  name="contacts.c$grad_years" required="true" > 


            </td>
            
            
                    <td>Gender</td>
            <td>

          
            <rn:widget path="input/SelectionInput" label_input="" name="contacts.c$gender" required="true" > 
       </td>
            
            
          </tr>
          
          </table>
          <table class="option">
          <tr>
            <td colspan="3">Current Career Interest:</td>
          </tr>
          <tr>
            <td><input type="checkbox" class="checkbox" id="ag_food_naturalresource" name="career_int[]" required="">Ag, Food & Natural Resource</td>
            
            <td>
              <input type="checkbox" class="checkbox" id="art_comm_infosyst" name="career_int[]" required="">Art, Communication & Info System
            </td>
            <td><input type="checkbox" class="checkbox" id="business_manage_admin" name="career_int[]"  required="">Business, Management & Admin</td>
          </tr>
          <tr>
            <td><input type="checkbox" class="checkbox" id="engine_manufature_tech" name="career_int[]"  required="">Engineering, Manufactoring & Technology</td>

            <td>
              <input type="checkbox" class="checkbox" id="health_science_tech" name="career_int[]" required="">Health Science Technology
            </td>
            
            <td><input type="checkbox" class="checkbox" id="human_services" name="career_int[]" required="">Human Services</td>
          </tr>
        </table>
      </fieldset>
      <div class="eninfo">
        <h1>Enrollment Info</h1>
        <!-- <a  class="add-fall-sem ad-sem">Add New Fall Semester</a> -->
        <a  class="add-spring-sem ad-sem">Add New Semester</a>
      </div>
      <div class="spring-sem-box sem-box default-sem-box">
        <div style="float: left;">
          <div class="choice-label">Semester</div>
          <select name="semyear[]" class="spring-sem-year sem-year"  required="">
            <option value="">Select</option>
             <?php 

             //$roql = "SELECT * FROM SemesterObj.Spring_Semesters";
              $roql = 'select semester.id as sid, semester.name as semester, year from CoursesObj.Course_Offer group by semester, year order by year';
              $resultSet = RightNow\Connect\v1_1\ROQL::query($roql);
              $queryResults = $resultSet->next();
               while($data = $queryResults->next())
              {
                ?> 
              <option value='<?=$data['Year'].$data['sid'] ?>'><?= $data['semester'].' '.$data['Year'] ?></option>
              <?php }
              ?>
          </select>
        </div>
      <div style="float: right;">
          
          <div class="choice-label"> # of Courses Desired</div>
          <td><input type="number" name="desired[]" class="desired numbers-only" min="0" max="5" required=""/>
        </div>
        <div style="clear: both;"></div>
        <div style="float: left;">
          <div>
            <div class="choice-label">1st Choice:</div>
            <select class="spring-coption1" name="coption1[]" required disabled="" style="max-width: 300px;min-width: 300px;">
              <option value="">Select</option>
              
            </select>
          </div>
          <div>
            <div class="choice-label">2nd Choice:</div>
            <select class="spring-coption2" name="coption2[]"  disabled="" style="max-width: 300px;min-width: 300px;">
              <option value="">Select</option>
              
            </select>
          </div>
        </div>
        <div style="float: right;">
          <div>
            <div class="choice-label">3rd Choice:</div>
            <select class="spring-coption3" name="coption3[]"  disabled="" style="max-width: 300px;min-width: 300px;" >
              <option value="">Select</option>
              
            </select>
          </div>
          <div>
            <div class="choice-label">4th Choice: </div>
            <select class="spring-coption4" name="coption4[]"  disabled="" style="max-width: 300px;min-width: 300px;" >
              <option value="">Select</option>
              
            </select>
          </div>
          <a style="float: right;display: none;cursor: pointer;" onclick="$(this).parent().parent().remove()" class="remove-link">Remove</a>
        </div>
        <div style="clear: both;"></div>
      </div>
         <a  class="add-spring-sem ad-sem">Add New Semester</a>
      <div style="margin-top: 15px;text-align: center;"><button type="submit" name="submit" class="sub-btn">Submit</button>
      </div>
      
      
      
    </form>
    
     
    
  </div>
</div>
</div>
</main>
<script type="text/javascript">
  var host="<?= $_SERVER['SERVER_NAME']?>" ;
</script>
<script type="text/javascript" src="/euf/assets/java/submit-roster.js?ver=20170511"></script>