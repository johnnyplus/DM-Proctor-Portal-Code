<?php
//use RightNow\Utils\Url,RightNow\Connect\v1_2 as Connect;
//use RightNow\Connect\v1 as RNCPHP;

// For framework3.0
namespace Custom\Controllers;
use RightNow\Utils\Framework;
class ajaxSubmitRoster extends \RightNow\Controllers\Base
{
	//This is the constructor for the custom controller. Do not modify anything within
	//this function.
	function __construct()
	{
		parent::__construct();		
	}

	/**
		Fetch Organization from DB
	*/
	function getOrganization()
	{
		// $q=$_GET['q'];
		 $roql = "SELECT OrganizationId FROM SemesterObj.ContactOrg where SemesterObj.ContactOrg.ContactId ='".$this->session->getProfile()->c_id->value."'";
		 // $roql="SELECT ID as id,LookupName as text FROM Organization where LookupName like '%$q%' ";
		$response = $this->model('custom/Submit_roster_model')->roql_tabular_query($roql);
		if(!empty($response))
		{

		 $roql = "SELECT ID as id,LookupName as text FROM Organization where 
		 -- LookupName like '%$q%' and 
		 ID IN (".implode(',', $response).")";
		$response = $this->model('custom/Submit_roster_model')->roql_tabular_query($roql);

		}
		echo json_encode($response);
	}
	function saveSemester()
	{
		 $i=0;
		$ProctorName=$this->session->getProfile()->first_name->value." ".$this->session->getProfile()->last_name->value;
		foreach ($_POST['spring_semYear'] as $value) {
				$array['ContactID']=$_POST['userId'];
				$array['Spring_First_Choice']=$_POST['spring_opt1'][$i];
				$array['Choice_1st']=$_POST['choice1'][$i];
				if($_POST['spring_opt2'][$i])
				{
					$array['Spring_Second_Choice']=$_POST['spring_opt2'][$i];
					$array['Choice_2nd']=$_POST['choice2'][$i];
				}
				
			if($_POST['spring_opt3'][$i])
			{
				$array['Spring_Third_Choice']=$_POST['spring_opt3'][$i];
				$array['Choice_3rd']=$_POST['choice3'][$i];
			}
			if($_POST['spring_opt4'][$i])
			{
				$array['Spring_Fourth_Choice']=$_POST['spring_opt4'][$i];
				$array['Choice_4th']=$_POST['choice4'][$i];	
			}
				

				
				
				
				

				$array['SpringSemestersName']=$value;
				$array['Desired']=$_POST['desired'][$i];
				$array['ProctorId']=$this->session->getProfile()->c_id;
				$array['ProctorName']=$ProctorName;
			 $this->load->model('custom/Submit_roster_model');
			$response = $this->Submit_roster_model->saveSpringSemester($array);
			 $i++;
		} 
		 $this->load->model('custom/Submit_roster_model');
			$response = $this->Submit_roster_model->saveIncident($_POST['userId']);
		
 
		// $i=0;
		// foreach ($_POST['fall_semYear'] as $value) {
		// 		$array['ContactID']=$_POST['userId'];
		// 		$array['Fall_First_Choice']=$_POST['fall_opt1'][$i];
		// 		$array['Fall_Second_Choice']=$_POST['fall_opt2'][$i];
		// 		$array['Fall_Third_Choice']=$_POST['fall_opt3'][$i];
		// 		$array['Fall_Fourth_Choice']=$_POST['fall_opt4'][$i];
		// 		$array['FallSemestersName']=$value;
		// 		$array['FallDesired']=$_POST['fall_desired'][$i];
		// 		$array['ProctorName']=$ProctorName;
		// 	 $this->load->model('custom/Submit_roster_model');
		// 	$response = $this->Submit_roster_model->saveFallSemester($array);
		// 	 $i++;
		// }
		return true;
	}

	function getSemester($id)
	{
			$semOpt=array();

            $roql = "SELECT Semester,year FROM CoursesObj.Course_Selection where Contact='".$id."'";

			$response = $this->model('custom/Submit_roster_model')->roql_tabular_query($roql);

			if(count($response)>0)
			{
				foreach ($response as $key => $value) {
					$roql = "select semester.id as sid, semester.name as semester, year from CoursesObj.Course_Offer where semester.id='".$value['Semester']."' and year='".$value['Year']."' group by semester, year order by year";
					$response = $this->model('custom/Submit_roster_model')->roql_tabular_query($roql);
					$semOpt[]=$response[0];
				}
			}
		
			echo json_encode($semOpt);

	}
	function getSemesterDetails($contactId,$semId)
	{ 
		
				$roql="SELECT *,CoursesObj.Course_Selection.Choice1_Status.LookupName Choice1_Status,
				                           CoursesObj.Course_Selection.Choice2_Status.LookupName Choice2_Status,
				                           CoursesObj.Course_Selection.Choice3_Status.LookupName Choice3_Status,
				                           CoursesObj.Course_Selection.Choice4_Status.LookupName Choice4_Status
				 				 FROM CoursesObj.Course_Selection where Contact='".$contactId."' and Semester='".substr($semId,4)."' and Year='".substr($semId,0,4)."'";
            $this->load->model('custom/Submit_roster_model');
			$response = $this->Submit_roster_model->roql_tabular_query($roql);
			echo json_encode($response[0]);
	}
	function updateSpringSemesterDetails($id)
	{
			$array['First_Choice']=$_POST['spring_opt1'];
			$array['Second_Choice']=$_POST['spring_opt2'];
			$array['Third_Choice']=$_POST['spring_opt3'];
			$array['Fourth_Choice']=$_POST['spring_opt4'];
			$this->load->model('custom/Submit_roster_model');
			$response = $this->Submit_roster_model->updateSpringSemester($id,$array);
	}
	function updateFallSemesterDetails($id)
	{

			$array['Fall_First_Choice']=$_POST['fall_opt1'];
			$array['Fall_Second_Choice']=$_POST['fall_opt2'];
			$array['Fall_Third_Choice']=$_POST['fall_opt3'];
			$array['Fall_Fourth_Choice']=$_POST['fall_opt4'];
			$this->load->model('custom/Submit_roster_model');
			$response = $this->Submit_roster_model->updateFallSemester($id,$array);
	}
	function getDetailsByEmail()
	{
		$roql = "SELECT *,Contact.CustomFields.c.home_campus_sales
						,Contact.CustomFields.c.ag_food_naturalresource
						,Contact.CustomFields.c.grad_year
						,Contact.CustomFields.c.art_comm_infosyst
						,Contact.CustomFields.c.business_manage_admin
						,Contact.CustomFields.c.engine_manufature_tech
						,Contact.CustomFields.c.health_science_tech
						,Contact.CustomFields.c.human_services
						,Contact.CustomFields.c.grad_years
						 FROM Contact C Where C.Emails.EmailList.Address ='".$_POST['email']."'";
		$this->load->model('custom/Submit_roster_model');
		$responseContact = $this->Submit_roster_model->roql_tabular_query($roql);
		if(count($responseContact)>0)
		{
			$roql="SELECT * from CoursesObj.Course_Selection where Contact='".$responseContact[0]['ID']."'";
			$this->load->model('custom/Submit_roster_model');
			$response = $this->Submit_roster_model->roql_tabular_query($roql);
			
			$response=array_merge($responseContact[0],array("Sem"=>$response));
			echo json_encode($response);
		}
		
	}
	function updateSemester()
	{
				$this->load->model('custom/Submit_roster_model');	
				$response = $this->Submit_roster_model->roql_delete_query($_POST['userId']);
				$this->saveSemester();
		        return true;
	}
	function getCourse() {
			if($_SERVER['REQUEST_METHOD'] === 'POST') {
				$semester = $_POST['semester'];
				$year = $_POST['year'];
			} else {
				$semester = $_GET['semester'];
				$year = $_GET['year'];
			}
			$result = $this->model('custom/Submit_roster_model')->getCourse($semester, $year);
			//print_r($result);
			echo json_encode($result);
		}
	function disableContact($contactId)
	{
		$this->model('custom/Submit_roster_model')->disableContact($contactId);
		header("Location: /app/custom/ochs/proctor");
	}
}